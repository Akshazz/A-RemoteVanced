# 🚀 START HERE - RemoteBridge JSON Version

Welcome! You have RemoteBridge with **JSON file-based storage** instead of MySQL.

## ⚡ 2-Minute Quick Start

### Choose Your Method

#### Method 1: Use the Setup Script (Recommended)

**Linux / macOS:**
```bash
chmod +x start.sh
./start.sh
```

**Windows:**
```bash
start.bat
```

Then follow the prompts!

#### Method 2: Manual Start

**Any System:**
```bash
php -S 127.0.0.1:8000
```

#### Method 3: Verify Everything First
```bash
php verify-setup.php
```

This checks that your setup is correct.

---

## 📖 What to Read Next

### I want to...

**Get started immediately** → Read: [QUICKSTART.md](QUICKSTART.md)

**Understand the JSON version** → Read: [README-JSON.md](README-JSON.md)

**Compare to MySQL version** → Read: [COMPARISON.md](COMPARISON.md)

**Troubleshoot a problem** → Read: [TROUBLESHOOTING.md](TROUBLESHOOTING.md)

**See what changed** → Read: [CHANGELOG-JSON.md](CHANGELOG-JSON.md)

---

## 🎯 Quick Reference

### Files You Need

✅ **index-json.php** - Main entry point  
✅ **config-json.php** - Configuration  
✅ **database-json-v2.php** - Database layer  
✅ **public/app.js** - Frontend  
✅ **start.sh or start.bat** - Setup helper  

### Files for Reference

📖 **README-JSON.md** - Full documentation  
📖 **QUICKSTART.md** - Quick start guide  
📖 **TROUBLESHOOTING.md** - Problem solving  
📖 **COMPARISON.md** - MySQL vs JSON  
📖 **CHANGELOG-JSON.md** - What changed  

---

## ❓ FAQ

### Q: Do I need XAMPP?
**A:** No! This version uses only PHP.

### Q: Do I need MySQL?
**A:** No! Everything uses JSON files in the `/data` folder.

### Q: Will my data be saved?
**A:** Yes! Automatically in JSON files.

### Q: Can I back up my data?
**A:** Yes! Just copy the `/data` folder.

### Q: How do I move it to another computer?
**A:** Copy the entire folder. It's completely portable!

### Q: Is it slower than MySQL?
**A:** For small deployments, no. For 100+ devices, use MySQL.

### Q: What if something breaks?
**A:** See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) - it has solutions for everything!

---

## 🚀 Getting Started

### Step 1: Start the Server

```bash
# Choose ONE:

# Option A (simplest)
php -S 127.0.0.1:8000

# Option B (use setup script)
./start.sh   # Linux/Mac
start.bat    # Windows

# Option C (check everything first)
php verify-setup.php
php -S 127.0.0.1:8000
```

### Step 2: Open in Browser

```
http://localhost:8000/index-json.php
```

### Step 3: You'll See

- **Welcome Screen** - First time setup
- **Your Remote ID** - A 9-digit number
- **Go Online Button** - Make yourself visible
- **Connect to Remote ID** - Enter someone else's ID to connect

### Step 4: Test It

1. Open in a second browser/device
2. Get the Remote ID from the first window
3. Paste it into the second window
4. Click Connect
5. Accept the connection
6. See the other screen!

---

## 📂 Project Structure

```
RemoteBridge/
├── index-json.php          ← OPEN THIS IN BROWSER
├── config-json.php         ← Customize settings here
├── database-json-v2.php    ← Database layer
├── public/
│   ├── app.js
│   └── ... other assets
├── agent/                  ← Optional control agent
├── admin/                  ← Admin settings (optional)
├── data/                   ← Your database (auto-created)
│   ├── devices.json
│   ├── sessions.json
│   ├── signals.json
│   └── app_settings.json
├── start.sh                ← Setup script (Linux/Mac)
├── start.bat               ← Setup script (Windows)
├── verify-setup.php        ← Verification tool
├── QUICKSTART.md           ← Read this first!
├── README-JSON.md          ← Full docs
├── TROUBLESHOOTING.md      ← Problem solving
├── COMPARISON.md           ← JSON vs MySQL
└── CHANGELOG-JSON.md       ← What changed
```

---

## ⚙️ Customization

### Change Network Access Code

Edit `config-json.php`:
```php
'network' => [
    'access_code' => '12345',  ← Set any code here
],
```

Then restart the server.

### Enable LAN Access

Edit `config-json.php`:
```php
'agent' => [
    'host' => '0.0.0.0',  ← Change from 127.0.0.1
    'port' => 8791,
],
```

Then restart the server.

### More Options

See [README-JSON.md](README-JSON.md) for complete configuration options.

---

## 🆘 Troubleshooting

### "Address already in use"
```bash
# Use a different port:
php -S 127.0.0.1:9000
# Then open: http://localhost:9000/index-json.php
```

### "Cannot reach localhost"
- Make sure PHP server is running
- Try: http://127.0.0.1:8000/index-json.php
- Check firewall settings

### "Data not saving"
```bash
# Check directory permissions:
ls -la data/

# Fix if needed:
chmod 700 data/
```

### Other problems?
See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) - comprehensive guide included!

---

## 📞 Support Resources

| Issue | Where to Look |
|-------|---------------|
| Getting started | [QUICKSTART.md](QUICKSTART.md) |
| Problems | [TROUBLESHOOTING.md](TROUBLESHOOTING.md) |
| Full documentation | [README-JSON.md](README-JSON.md) |
| Setup issues | [verify-setup.php](verify-setup.php) |
| Comparing versions | [COMPARISON.md](COMPARISON.md) |
| What changed | [CHANGELOG-JSON.md](CHANGELOG-JSON.md) |

---

## 🎓 Learning Path

### For Complete Beginners
1. Run `./start.sh` (Linux/Mac) or `start.bat` (Windows)
2. Open http://localhost:8000/index-json.php
3. Read [QUICKSTART.md](QUICKSTART.md)
4. Try connecting to another device

### For MySQL Users
1. Compare with [COMPARISON.md](COMPARISON.md)
2. Read [README-JSON.md](README-JSON.md)
3. Notice: Everything works the same!

### For Developers
1. Review [CHANGELOG-JSON.md](CHANGELOG-JSON.md)
2. Check [database-json-v2.php](database-json-v2.php) source
3. All queries work identically!

---

## ✅ Quick Checklist

Before you ask for help:

- [ ] Ran `php verify-setup.php` successfully?
- [ ] Started the PHP server?
- [ ] Opened http://localhost:8000/index-json.php?
- [ ] Checked browser console (F12) for errors?
- [ ] Checked `/data` folder exists and is writable?
- [ ] Restarted the server after changing config?

If all checks pass, RemoteBridge should work!

---

## 🎉 You're Ready!

That's all you need to know to get started.

### Next: Run the server!

```bash
./start.sh    # OR
php -S 127.0.0.1:8000
```

Then open: **http://localhost:8000/index-json.php**

---

## 📚 Full Documentation Available

- [QUICKSTART.md](QUICKSTART.md) - 2-minute setup
- [README-JSON.md](README-JSON.md) - Complete reference
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) - Solve issues
- [COMPARISON.md](COMPARISON.md) - MySQL vs JSON
- [CHANGELOG-JSON.md](CHANGELOG-JSON.md) - What changed

---

### Welcome to RemoteBridge! 🚀

**No XAMPP. No MySQL. Just JSON.**

Enjoy!

#!/usr/bin/env node
/**
 * RemoteBridge control agent
 * -----------------------------------------------------------------------
 * Runs on the HOST machine (the one being remote-controlled) and is the
 * only part of this project that touches the real OS mouse/keyboard.
 * The browser tab cannot do this itself — browsers deliberately do not let
 * a web page control the operating system — so this small local process
 * bridges the gap.
 *
 * Security model:
 *   - Binds to 127.0.0.1 only (never exposed to the network).
 *   - Requires a random token (printed on first run, saved to .token)
 *     that the host must paste into the RemoteBridge page before the
 *     browser tab is allowed to send it commands. This stops any other
 *     tab/website open in the same browser from silently commanding it.
 *   - Only moves the mouse / sends keystrokes — it does not read the
 *     screen, files, or anything else on the machine.
 *
 * Only run this if you intend to let a specific, trusted remote person
 * control this computer, and only while that session is active. Close
 * this process (Ctrl+C) to immediately revoke all control.
 *
 * Setup:
 *   cd agent
 *   npm install
 *   node control-agent.js
 *
 * Then paste the printed token into the "Native control agent" field on
 * the Host tab of the RemoteBridge page and click Connect.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

let robot;
try {
  robot = require('robotjs');
} catch (e) {
  console.error(
    '\nCould not load "robotjs". This package needs native build tools.\n' +
    'Install with: npm install\n' +
    'If that fails, see https://github.com/octalmage/robotjs#building for your OS.\n'
  );
  process.exit(1);
}

const PORT = 8791;
const TOKEN_FILE = path.join(__dirname, '.token');

function loadOrCreateToken() {
  if (fs.existsSync(TOKEN_FILE)) {
    return fs.readFileSync(TOKEN_FILE, 'utf8').trim();
  }
  const token = crypto.randomBytes(24).toString('hex');
  fs.writeFileSync(TOKEN_FILE, token, { mode: 0o600 });
  return token;
}

const TOKEN = loadOrCreateToken();
const { width: screenW, height: screenH } = robot.getScreenSize();

// Keep a light rate limit so a runaway/buggy channel can't flood input events.
let lastMoveAt = 0;

function applyCommand(cmd) {
  try {
    switch (cmd.type) {
      case 'move': {
        const now = Date.now();
        if (now - lastMoveAt < 8) return; // ~120fps ceiling
        lastMoveAt = now;
        robot.moveMouse(Math.round(cmd.x * screenW), Math.round(cmd.y * screenH));
        break;
      }
      case 'button': {
        const btn = cmd.button === 2 ? 'right' : cmd.button === 1 ? 'middle' : 'left';
        robot.moveMouse(Math.round(cmd.x * screenW), Math.round(cmd.y * screenH));
        if (cmd.action === 'down') robot.mouseToggle('down', btn);
        else robot.mouseToggle('up', btn);
        break;
      }
      case 'wheel': {
        robot.scrollMouse(Math.round(-cmd.deltaX / 4), Math.round(-cmd.deltaY / 4));
        break;
      }
      case 'key': {
        const key = mapKey(cmd.key);
        if (!key) return;
        if (cmd.action === 'down') robot.keyToggle(key, 'down');
        else robot.keyToggle(key, 'up');
        break;
      }
    }
  } catch (e) {
    console.error('Failed to apply command', cmd.type, e.message);
  }
}

/** Map a browser KeyboardEvent.key to a robotjs key name (covers the common cases). */
function mapKey(key) {
  if (!key) return null;
  const map = {
    ' ': 'space', Enter: 'enter', Backspace: 'backspace', Tab: 'tab', Escape: 'escape',
    ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right',
    Shift: 'shift', Control: 'control', Alt: 'alt', Meta: 'command', Delete: 'delete',
    Home: 'home', End: 'end', PageUp: 'pageup', PageDown: 'pagedown',
  };
  if (map[key]) return map[key];
  if (key.length === 1) return key.toLowerCase();
  if (/^F\d{1,2}$/.test(key)) return key.toLowerCase();
  return null;
}

const wss = new WebSocketServer({ host: '127.0.0.1', port: PORT });
console.log(`RemoteBridge control agent listening on ws://127.0.0.1:${PORT}`);
console.log(`Token (paste this into the RemoteBridge Host tab): ${TOKEN}`);
console.log('Press Ctrl+C to stop and revoke control at any time.\n');

wss.on('connection', (ws) => {
  let authed = false;
  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch (_) { return; }

    if (!authed) {
      if (msg.type === 'auth' && msg.token === TOKEN) {
        authed = true;
        ws.send(JSON.stringify({ type: 'auth_ok' }));
        console.log('Browser tab authenticated.');
      } else {
        ws.send(JSON.stringify({ type: 'auth_fail' }));
        ws.close();
      }
      return;
    }
    applyCommand(msg);
  });
  ws.on('close', () => { if (authed) console.log('Browser tab disconnected.'); });
});

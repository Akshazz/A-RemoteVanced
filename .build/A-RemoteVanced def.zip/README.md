# RemoteBridge 2.0 — Native PHP Database Edition

This edition uses **native PHP `mysqli`** to connect to **MySQL/MariaDB**. SQLite has been removed.

## Requirements
- PHP 8.1+
- PHP `mysqli` extension
- MySQL 8+ or MariaDB 10.6+
- Browser with WebRTC support

## Database setup
Configure with environment variables:

- `RB_DB_HOST`
- `RB_DB_PORT`
- `RB_DB_NAME`
- `RB_DB_USER`
- `RB_DB_PASSWORD`

Or edit `config.php`.

Run the PHP migration system:

```bash
php database/migrate.php
```

It creates the MySQL/MariaDB database and applies versioned PHP migrations.

## Main program

`index.php` is the default/main application entry point. `server.php` remains only as a backward-compatible router.

## Run

```bash
php database/migrate.php
php -S 0.0.0.0:8080 index.php
```

Open `http://127.0.0.1:8080/`.

## Database tables
- `migrations`
- `devices`
- `sessions`
- `signals`
- `transfer_history`
- `audit_log`

No `.sqlite` file is required or used.

## Security
The MAC-derived Remote ID is an identifier, not a secret. Use separate high-entropy pairing/authorization tokens. Production deployments should use HTTPS, authentication, rate limiting, and TURN where needed.

## Database SQL

A complete native MySQL/MariaDB schema is included at:

`database/schema.sql`

You can import it directly with MySQL/MariaDB, for example:

`mysql -u root -p < database/schema.sql`

The PHP migration runner is also available at `database/migrate.php`.


## Running under XAMPP/Apache in a subfolder

If the project is extracted to `htdocs/A-RemoteVanced`, open:

`http://localhost/A-RemoteVanced/`

The included `.htaccess` routes `/A-RemoteVanced/health` and `/A-RemoteVanced/api/info` back to `index.php`. The frontend also detects the installation folder automatically, so it does not incorrectly request `http://localhost/health`.

The `ws://127.0.0.1:5500//ws` message is from a Live Server/browser reload extension. It is not a RemoteBridge WebRTC connection and is not required by this PHP project. Disable Live Server/reload.js for this project, or simply ignore that separate console message.

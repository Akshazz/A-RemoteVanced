<?php
declare(strict_types=1);

require __DIR__ . '/database.php';
$config = require __DIR__ . '/config.php';

// Main/default application entry point.  API requests are kept in this file
// so the project can be deployed with Apache/Nginx without a separate router.
$requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
$basePath = ($scriptDir === '/' || $scriptDir === '.') ? '' : rtrim($scriptDir, '/');
$path = $requestPath;
if ($basePath !== '' && str_starts_with($path, $basePath)) {
    $path = substr($path, strlen($basePath)) ?: '/';
}
if ($path[0] !== '/') $path = '/' . $path;

if ($path === '/health') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $db = db();
        $row = $db->query('SELECT 1 AS ok')->fetch_assoc();
        echo json_encode([
            'ok' => (bool)($row['ok'] ?? false),
            'database' => 'mysql',
            'app' => $config['app'],
        ], JSON_UNESCAPED_SLASHES);
    } catch (Throwable $e) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'database' => 'unavailable']);
    }
    exit;
}

if ($path === '/api/info') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'name' => $config['app']['name'],
        'version' => $config['app']['version'],
        'database' => 'MySQL/MariaDB via native PHP mysqli',
        'webrtc' => true,
        'entrypoint' => 'index.php',
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

if ($path !== '/' && $path !== '/index.php') {
    http_response_code(404);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Not found']);
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="RemoteBridge PHP and WebRTC remote transfer platform">
<title>RemoteBridge</title>
<style>
:root{font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#eaf1ff;background:#07101f}
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 20% 10%,#15315a 0,#07101f 42%,#050a13 100%)}
main{width:min(1120px,calc(100% - 32px));margin:48px auto}.top{display:flex;justify-content:space-between;gap:20px;align-items:center;margin-bottom:24px}
h1{margin:0;font-size:clamp(28px,5vw,46px)}.sub{color:#9db0ca;margin:8px 0 0}.status{border:1px solid #2c4262;background:#0e1b2f;border-radius:999px;padding:9px 14px;font-size:13px}
.grid{display:grid;grid-template-columns:1.4fr .8fr;gap:18px}.card{background:rgba(14,27,47,.88);border:1px solid #253b5a;border-radius:20px;padding:24px;box-shadow:0 20px 70px rgba(0,0,0,.25)}
.card h2{margin:0 0 10px}.muted{color:#9db0ca}.actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:20px}button{border:0;border-radius:11px;padding:11px 15px;background:#2b6de8;color:white;font-weight:700;cursor:pointer}button.secondary{background:#20324d}
.code{margin-top:16px;padding:15px;border-radius:12px;background:#07101c;border:1px solid #1e3049;color:#bcd0ec;font-family:ui-monospace,monospace;overflow:auto}.features{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:18px}.feature{padding:13px;border-radius:12px;background:#0a1729;border:1px solid #1b304c}.feature b{display:block;margin-bottom:4px}
@media(max-width:760px){.grid{grid-template-columns:1fr}.top{align-items:flex-start;flex-direction:column}.features{grid-template-columns:1fr}}
</style>
</head>
<body>
<main>
  <div class="top">
    <div><h1>RemoteBridge</h1><p class="sub">Native PHP + MySQL/MariaDB signaling and WebRTC transfer platform</p></div>
    <div id="status" class="status">Checking database…</div>
  </div>
  <section class="grid">
    <article class="card">
      <h2>Remote endpoint</h2>
      <p class="muted">The default application entry point is <strong>index.php</strong>. WebRTC peer traffic is intended to remain direct between endpoints; the PHP server handles coordination.</p>
      <div class="features">
        <div class="feature"><b>WebRTC</b><span class="muted">Peer data channels</span></div>
        <div class="feature"><b>Chunked transfer</b><span class="muted">Designed for large files</span></div>
        <div class="feature"><b>Clipboard</b><span class="muted">Real-time sync layer</span></div>
        <div class="feature"><b>Native DB</b><span class="muted">PHP mysqli + MySQL</span></div>
      </div>
      <div class="actions"><button onclick="checkHealth()">Check connection</button><button class="secondary" onclick="loadInfo()">System info</button></div>
      <div id="output" class="code">Ready.</div>
    </article>
    <aside class="card">
      <h2>Installation</h2>
      <p class="muted">1. Configure MySQL credentials in <code>config.php</code> or environment variables.</p>
      <p class="muted">2. Run the migration:</p>
      <div class="code">php database/migrate.php</div>
      <p class="muted">3. Start PHP:</p>
      <div class="code">php -S 0.0.0.0:8080 index.php</div>
    </aside>
  </section>
</main>
<script>
const RB_BASE = <?= json_encode($basePath, JSON_UNESCAPED_SLASHES) ?>;
function rbUrl(path){ return RB_BASE + path; }
async function checkHealth(){
  const s=document.getElementById('status'),o=document.getElementById('output');
  s.textContent='Checking…';
  try{const r=await fetch(rbUrl('/health'),{cache:'no-store'});const j=await r.json();
    s.textContent=j.ok?'Database online':'Database unavailable';
    o.textContent=JSON.stringify(j,null,2);
  }catch(e){s.textContent='Server unavailable';o.textContent=String(e)}
}
async function loadInfo(){const o=document.getElementById('output');try{o.textContent=JSON.stringify(await (await fetch(rbUrl('/api/info'),{cache:'no-store'})).json(),null,2)}catch(e){o.textContent=String(e)}}
checkHealth();
</script>
</body>
</html>

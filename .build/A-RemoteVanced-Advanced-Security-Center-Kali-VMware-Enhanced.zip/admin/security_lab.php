<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';

if (!rb_is_authenticated()) { header('Location: ../login.php'); exit; }
if (($_SESSION['role'] ?? '') !== 'admin') { http_response_code(403); exit('Admin access required.'); }

$config = require __DIR__ . '/../config.php';
$db = db();
$lab = $config['security_lab'] ?? [];

function lab_json(array $d, int $c=200): never {
    http_response_code($c);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($d, JSON_UNESCAPED_SLASHES);
    exit;
}
function lab_local_only(): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!in_array($ip, ['127.0.0.1','::1'], true)) lab_json(['error'=>'Security Lab control is local-machine only.'],403);
}
function lab_scope(mysqli $db, int $id): array {
    $q=$db->prepare("SELECT * FROM security_scopes WHERE id=? AND authorized=1 LIMIT 1");
    $q->bind_param('i',$id); $q->execute();
    $r=$q->get_result()->fetch_assoc();
    if (!$r) lab_json(['error'=>'Only an explicitly authorized scope may be used.'],403);
    $target=trim((string)$r['target']);
    $ip=filter_var($target,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)?$target:gethostbyname($target);
    if (!$ip || $ip===$target && !filter_var($target,FILTER_VALIDATE_IP)) lab_json(['error'=>'Scope target could not be resolved.'],400);
    return ['scope'=>$r,'target'=>$target,'ip'=>$ip];
}
function lab_cmd(string $program, array $args, int $timeout=45): array {
    $cmd = escapeshellarg($program);
    foreach ($args as $a) $cmd .= ' ' . escapeshellarg((string)$a);
    $desc=[1=>['pipe','w'],2=>['pipe','w']];
    $p=proc_open($cmd,$desc,$pipes);
    if (!is_resource($p)) return ['code'=>1,'stdout'=>'','stderr'=>'Could not start process.'];
    stream_set_blocking($pipes[1],false); stream_set_blocking($pipes[2],false);
    $out=''; $err=''; $start=microtime(true);
    while (true) {
        $out .= stream_get_contents($pipes[1]);
        $err .= stream_get_contents($pipes[2]);
        $st=proc_get_status($p);
        if (!$st['running']) { $code=(int)$st['exitcode']; break; }
        if ((microtime(true)-$start) > $timeout) {
            proc_terminate($p);
            $code=124; $err.="Timed out after {$timeout}s.";
            break;
        }
        usleep(100000);
    }
    $out .= stream_get_contents($pipes[1]); $err .= stream_get_contents($pipes[2]);
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    return ['code'=>$code,'stdout'=>$out,'stderr'=>$err];
}
function lab_detect_vmrun(string $configured): string {
    if ($configured && is_file($configured)) return $configured;
    $candidates=[];
    if (PHP_OS_FAMILY==='Windows') {
        $candidates=[
          'C:\\Program Files (x86)\\VMware\\VMware Workstation\\vmrun.exe',
          'C:\\Program Files\\VMware\\VMware Workstation\\vmrun.exe'
        ];
    } else {
        $candidates=['/usr/bin/vmrun','/usr/local/bin/vmrun'];
    }
    foreach ($candidates as $p) if (is_file($p)) return $p;
    return $configured;
}
function lab_vmrun(string $vmrun, string $action, string $vmx=''): array {

    if ($vmrun==='') return ['code'=>2,'stdout'=>'','stderr'=>'VMware vmrun is not configured.'];
    if (!is_file($vmrun)) return ['code'=>2,'stdout'=>'','stderr'=>'Configured vmrun path does not exist.'];
    $args=['-T','ws'];
    if ($action==='list') $args[]='list';
    else { $args[]=$action; $args[]=$vmx; }
    return lab_cmd($vmrun,$args,30);
}
function lab_guest_command(array $lab, string $command): array {
    /* Prefer SSH when a key is configured. This keeps guest credentials out
       of process arguments. Otherwise fall back to VMware runProgramInGuest. */
    if (!empty($lab['ssh_key']) && !empty($lab['ssh_host']) && !empty($lab['ssh_user'])) {
        $ssh=PHP_OS_FAMILY==='Windows' ? 'ssh.exe' : 'ssh';
        $args=['-i',$lab['ssh_key'],'-p',(string)$lab['ssh_port'],'-o','BatchMode=yes','-o','StrictHostKeyChecking=accept-new',
               $lab['ssh_user'].'@'.$lab['ssh_host'],$command];
        return lab_cmd($ssh,$args,(int)$lab['timeout']);
    }
    if (!empty($lab['vmrun']) && !empty($lab['vmx']) && !empty($lab['guest_user']) && !empty($lab['guest_password'])) {
        $encoded=base64_encode($command);
        $args=['-T','ws','-gu',$lab['guest_user'],'-gp',$lab['guest_password'],'runProgramInGuest',$lab['vmx'],
               '/bin/bash','-lc',"echo ".escapeshellarg($encoded)." | base64 -d | bash"];
        return lab_cmd($lab['vmrun'],$args,(int)$lab['timeout']);
    }
    return ['code'=>2,'stdout'=>'','stderr'=>'Configure RB_KALI_SSH_KEY + RB_KALI_SSH_HOST/USER or VMware vmrun + guest credentials.'];
}
function lab_allowed_profile(string $p): array {
    $profiles=[
      'quick'=>['-Pn','-sV','--top-ports','100'],
      'service'=>['-Pn','-sV','-sC','--top-ports','100'],
      'safe-vuln'=>['-Pn','-sV','--script','safe','--top-ports','100'],
      'vuln-lab'=>['-Pn','-sV','--script','vuln','--top-ports','100'],
    ];
    return $profiles[$p] ?? $profiles['quick'];
}
function lab_ensure_tables(mysqli $db): void {
    $db->query("CREATE TABLE IF NOT EXISTS security_lab_runs (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      scope_id BIGINT UNSIGNED NULL, tool VARCHAR(40) NOT NULL,
      profile VARCHAR(60) NOT NULL, command_text TEXT NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'running', exit_code INT NULL,
      output MEDIUMTEXT NULL, created_by BIGINT UNSIGNED NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      finished_at DATETIME NULL, INDEX(scope_id), INDEX(created_at)
    ) ENGINE=InnoDB");
}
lab_ensure_tables($db);

if (isset($_GET['api'])) {
    lab_local_only();
    $api=(string)$_GET['api'];

    if (!$lab['enabled']) lab_json(['error'=>'Security Lab is disabled. Set RB_SECURITY_LAB_ENABLED=1.'],403);

    if ($api==='config') {
        lab_json([
          'enabled'=>true,
          'vmware_configured'=>lab_detect_vmrun((string)$lab['vmrun'])!=='' && !empty($lab['vmx']),
          'ssh_configured'=>!empty($lab['ssh_key']) && !empty($lab['ssh_host']) && !empty($lab['ssh_user']),
          'vmx'=>$lab['vmx'] ?: null,
          'target_timeout'=>(int)$lab['timeout']
        ]);
    }
    if ($api==='vm_list') {
        $r=lab_vmrun(lab_detect_vmrun((string)$lab['vmrun']),'list');
        lab_json(['ok'=>$r['code']===0,'output'=>trim($r['stdout']?:$r['stderr'])]);
    }
    if ($api==='vm_start' && $_SERVER['REQUEST_METHOD']==='POST') {
        $r=lab_vmrun(lab_detect_vmrun((string)$lab['vmrun']),'start',(string)$lab['vmx']);
        rb_audit_log($db,'security_lab_vm_start',null,['code'=>$r['code']]);
        lab_json(['ok'=>$r['code']===0,'output'=>trim($r['stdout']?:$r['stderr'])],$r['code']===0?200:500);
    }
    if ($api==='vm_stop' && $_SERVER['REQUEST_METHOD']==='POST') {
        $r=lab_vmrun(lab_detect_vmrun((string)$lab['vmrun']),'stop',(string)$lab['vmx']);
        rb_audit_log($db,'security_lab_vm_stop',null,['code'=>$r['code']]);
        lab_json(['ok'=>$r['code']===0,'output'=>trim($r['stdout']?:$r['stderr'])],$r['code']===0?200:500);
    }
    if ($api==='console' && $_SERVER['REQUEST_METHOD']==='POST') {
        $b=json_decode(file_get_contents('php://input') ?: '',true) ?: [];
        $kind=(string)($b['kind']??'');
        $allowed=['uname'=>'uname -a','ip'=>'ip addr','routes'=>'ip route','sockets'=>'ss -lntup',
          'whoami'=>'whoami','nmap-local'=>'nmap -Pn -sV --top-ports 100 127.0.0.1'];
        if (!isset($allowed[$kind])) lab_json(['error'=>'Unsupported console action.'],400);
        $r=lab_guest_command($lab,$allowed[$kind]);
        rb_audit_log($db,'security_lab_console',null,['action'=>$kind,'exit_code'=>$r['code']]);
        lab_json(['ok'=>$r['code']===0,'command'=>$allowed[$kind],'stdout'=>$r['stdout'],'stderr'=>$r['stderr'],'code'=>$r['code']]);
    }
    if ($api==='scan' && $_SERVER['REQUEST_METHOD']==='POST') {
        $b=json_decode(file_get_contents('php://input') ?: '',true) ?: [];
        $scopeId=(int)($b['scope_id']??0); $profile=(string)($b['profile']??'quick');
        $x=lab_scope($db,$scopeId);
        if ($profile==='vuln-lab' && empty($b['lab_confirm'])) lab_json(['error'=>'Vulnerability profile requires explicit lab confirmation.'],400);
        $args=lab_allowed_profile($profile); $args[]=$x['ip'];
        $command='nmap '.implode(' ',array_map('escapeshellarg',$args));
        $q=$db->prepare("INSERT INTO security_lab_runs(scope_id,tool,profile,command_text,created_by) VALUES(?,?,?,?,?)");
        $tool='nmap'; $uid=(int)$_SESSION['user_id']; $q->bind_param('isssi',$scopeId,$tool,$profile,$command,$uid); $q->execute(); $runId=(int)$q->insert_id;
        $r=lab_guest_command($lab,$command);
        $status=$r['code']===0?'completed':($r['code']===124?'timeout':'failed');
        $summary=trim($r['stdout']."\n".$r['stderr']);
        $u=$db->prepare("UPDATE security_lab_runs SET status=?,exit_code=?,output=?,finished_at=NOW() WHERE id=?");
        $u->bind_param('sisi',$status,$r['code'],$summary,$runId);$u->execute();
        rb_audit_log($db,'security_lab_nmap',null,['run_id'=>$runId,'scope'=>$x['target'],'profile'=>$profile,'status'=>$status]);
        lab_json(['ok'=>$r['code']===0,'run_id'=>$runId,'command'=>$command,'status'=>$status,'output'=>$summary,'target'=>$x['target']]);
    }
    if ($api==='runs') {
        $rows=$db->query("SELECT r.*,s.name scope_name,s.target FROM security_lab_runs r LEFT JOIN security_scopes s ON s.id=r.scope_id ORDER BY r.id DESC LIMIT 50")->fetch_all(MYSQLI_ASSOC);
        lab_json(['runs'=>$rows]);
    }
    lab_json(['error'=>'Unknown lab API'],404);
}
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RemoteBridge | Kali Security Lab</title><link rel="icon" href="../logo/favicon.ico">
<style>
:root{font-family:Inter,system-ui,sans-serif;color:#eaf1ff;background:#060b13}*{box-sizing:border-box}
body{margin:0;background:radial-gradient(circle at 10% 0,#183557,#060b13 48%);min-height:100vh}.nav{height:64px;background:#081423ee;border-bottom:1px solid #203750;display:flex;align-items:center;justify-content:space-between;padding:0 22px;position:sticky;top:0;z-index:5}.nav a{color:#bcd4f3;text-decoration:none}.wrap{max-width:1350px;margin:25px auto;padding:0 18px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.card{background:#0d1a2aee;border:1px solid #243d59;border-radius:14px;padding:18px}.wide{grid-column:1/-1}h1{margin:0 0 6px;font-size:25px}.muted{color:#8fa7c1;font-size:12.5px}.warn{border:1px solid #72591e;background:#2a210c;color:#f1d990;padding:12px;border-radius:10px;margin:12px 0}.ok{border:1px solid #24583c;background:#0c2a1d;color:#9ce4b8;padding:12px;border-radius:10px;margin:12px 0}.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.btn{border:0;border-radius:8px;padding:9px 13px;background:#2d73e8;color:white;font-weight:700;cursor:pointer}.btn.secondary{background:#20364f}.btn.danger{background:#7c3030}.field{display:flex;flex-direction:column;gap:5px;margin:9px 0}.field label{font-size:11px;color:#8fa7c1;font-weight:700}select,input{background:#07111e;color:#eaf1ff;border:1px solid #29415e;border-radius:8px;padding:10px}pre{margin:10px 0;background:#02070c;border:1px solid #1d3045;border-radius:10px;padding:13px;min-height:150px;max-height:430px;overflow:auto;white-space:pre-wrap;font:12px ui-monospace,monospace}.badge{padding:4px 8px;border-radius:999px;background:#183b59;font-size:10px}.dangerbox{border:1px solid #6e2e38;background:#2a1017;color:#f1aeb8;padding:12px;border-radius:10px;font-size:12px}@media(max-width:850px){.grid{grid-template-columns:1fr}.wide{grid-column:auto}}
</style></head><body>
<header class="nav"><b>RemoteBridge · Kali Security Lab</b><a href="security.php">← Security Center</a></header>
<main class="wrap">
<h1>Authorized Kali / VMware Lab</h1><div class="muted">Controlled offensive testing + defensive validation. Every scan requires an authorized scope.</div>
<div class="warn"><b>Lab boundary:</b> use only systems you own or have explicit permission to test. The vulnerability profile is disabled unless you explicitly confirm a lab target. This page is admin-only and local-machine-only.</div>
<div id="state" class="card">Checking lab configuration…</div>
<div class="grid">
<section class="card"><h2>VMware · Kali</h2><div class="muted">Local vmrun integration for a Kali VM.</div><div class="row" style="margin-top:12px"><button class="btn" onclick="vm('start')">Start VM</button><button class="btn secondary" onclick="vm('list')">VM status</button><button class="btn danger" onclick="vm('stop')">Stop VM</button></div><pre id="vmOut">No VMware command executed.</pre></section>
<section class="card"><h2>Kali console</h2><div class="muted">Safe operational presets; not a general remote shell.</div><div class="row" style="margin-top:12px"><button class="btn secondary" onclick="consoleRun('uname')">uname</button><button class="btn secondary" onclick="consoleRun('ip')">IP</button><button class="btn secondary" onclick="consoleRun('routes')">Routes</button><button class="btn secondary" onclick="consoleRun('sockets')">Sockets</button><button class="btn secondary" onclick="consoleRun('whoami')">Whoami</button><button class="btn secondary" onclick="consoleRun('nmap-local')">Nmap localhost</button></div><pre id="consoleOut">Ready.</pre></section>
<section class="card wide"><h2>Offensive validation</h2><div class="muted">Nmap runs inside Kali against a scope already marked authorized in Security Center.</div>
<div class="field"><label>Authorized scope</label><select id="scope"></select></div>
<div class="field"><label>Profile</label><select id="profile"><option value="quick">Quick · top 100 + service detection</option><option value="service">Service · default scripts + top 100</option><option value="safe-vuln">Safe NSE · safe scripts + top 100</option><option value="vuln-lab">Vulnerability lab · vuln NSE + top 100</option></select></div>
<label class="muted"><input id="labConfirm" type="checkbox" style="width:auto"> I confirm this is an authorized lab/test target.</label>
<div class="row" style="margin-top:10px"><button class="btn" onclick="scan()">Run Nmap</button></div><pre id="scanOut">No scan executed.</pre></section>
<section class="card wide"><h2>Run history</h2><button class="btn secondary" onclick="runs()">Refresh</button><pre id="runsOut">Loading…</pre></section>
</div></main>
<script>
const API='<?=htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES)?>';
async function api(n,o={}){const r=await fetch(API+'?api='+encodeURIComponent(n),Object.assign({headers:{'Content-Type':'application/json'}},o));const x=await r.json().catch(()=>({error:'Invalid response'}));if(!r.ok)throw Error(x.error||'Request failed');return x}
async function init(){try{const x=await api('config');state.innerHTML='<div class="ok"><b>Enabled.</b> '+(x.vmware_configured?'VMware configured. ':'VMware not configured. ')+(x.ssh_configured?'SSH configured.':'SSH not configured.')+'</div>';await scopes();await runs()}catch(e){state.innerHTML='<div class="dangerbox">'+e.message+'</div>'}}
async function scopes(){const x=await fetch('../admin/security.php?api=scopes');const d=await x.json();scope.innerHTML=d.scopes.filter(s=>Number(s.authorized)===1).map(s=>'<option value="'+s.id+'">'+s.name+' — '+s.target+'</option>').join('')||'<option value="">No authorized scopes</option>'}
async function vm(a){try{const x=await api(a==='list'?'vm_list':'vm_'+a,{method:a==='list'?'GET':'POST'});vmOut.textContent=x.output||'OK'}catch(e){vmOut.textContent=e.message}}
async function consoleRun(k){consoleOut.textContent='Running '+k+'…';try{const x=await api('console',{method:'POST',body:JSON.stringify({kind:k})});consoleOut.textContent=(x.command?('$ '+x.command+'\n\n'):'')+(x.stdout||'')+(x.stderr?'\n'+x.stderr:'')}catch(e){consoleOut.textContent=e.message}}
async function scan(){const id=Number(scope.value);if(!id){scanOut.textContent='No authorized scope.';return}if(profile.value==='vuln-lab'&&!labConfirm.checked){scanOut.textContent='Confirm the authorized lab target first.';return}scanOut.textContent='Running inside Kali…';try{const x=await api('scan',{method:'POST',body:JSON.stringify({scope_id:id,profile:profile.value,lab_confirm:labConfirm.checked})});scanOut.textContent='$ '+x.command+'\n\n'+x.output;await runs()}catch(e){scanOut.textContent=e.message}}
async function runs(){try{const x=await api('runs');runsOut.textContent=x.runs.map(r=>`#${r.id} ${r.status} ${r.profile} ${r.target||''}\n${r.command_text}\n${(r.output||'').slice(0,1200)}\n---`).join('\n')||'No runs.'}catch(e){runsOut.textContent=e.message}}
init();
</script></body></html>

<?php
declare(strict_types=1);
/* Optional migration for the Kali/VMware Security Lab history. The lab page
 * also self-heals this table, but keeping a migration makes deployments
 * reproducible. */
require_once __DIR__ . '/../database.php';
$db=db();
$db->query("CREATE TABLE IF NOT EXISTS security_lab_runs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  scope_id BIGINT UNSIGNED NULL,
  tool VARCHAR(40) NOT NULL,
  profile VARCHAR(60) NOT NULL,
  command_text TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'running',
  exit_code INT NULL,
  output MEDIUMTEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  finished_at DATETIME NULL,
  INDEX(scope_id), INDEX(created_at)
) ENGINE=InnoDB");
echo "Security Lab migration complete.\n";
